# Evidencias · Unidad III · Actividad 1

**Equipo:** (completar)
**Período de demostración:** 26 al 30 de octubre de 2026
**Empresa:** Empresa Demo · Moneda: MXN

## 1. Inicio de sesión

![Pantalla de inicio de sesión](capturas/01_login.png)

Pantalla de inicio de sesión del dashboard antes de autenticar.

## 2. Indicadores generales

![Indicadores generales](capturas/02_indicadores.png)

Período del 26 al 30 de octubre de 2026. Saldo inicial 1,000.00; ingresos 3,500.00; egresos 2,900.00; profit 600.00; saldo final 1,600.00 MXN. General en rojo: No. Cuentas en rojo: 1. Las cifras provienen de la consulta `miGeneralBalance`.

## 3. Detalle por cuenta

![Detalle por cuenta](capturas/03_detalle.png)

Banco 800.00, Ahorro 1,000.00 y Caja -200.00 (en rojo). La suma de los saldos finales por cuenta (800 + 1,000 - 200) coincide con el saldo final general de 1,600.00.

## 4. Caso de error

![Caso de error](capturas/04_error.png)

Consulta `miGeneralBalance` con un token que no es válido para la sesión. El backend responde "Sesión no válida" y no entrega datos.

## 5. Cambio de fechas

![Cambio de fechas](capturas/05_fechas.png)

Período cambiado a 26 y 27 de octubre de 2026. Los ingresos registrados el 27 de octubre suman 3,500.00. Los egresos están registrados el 28 de octubre, por lo que quedan fuera del período y el saldo final se recalcula a 4,500.00. Esto muestra que el dashboard vuelve a consultar el backend al cambiar las fechas.
